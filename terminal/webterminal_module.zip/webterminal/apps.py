from django.apps import AppConfig


class WebterminalConfig(AppConfig):
    name = 'webterminal'
    verbose_name = 'Web Terminal'
